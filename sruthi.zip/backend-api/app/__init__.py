"""
StreamForge Application Package.
"""
